//function added to dump the javascript 'proforma' map originally
//to verify the data was being duplicated in the model properly -chris
function dump(arr,level) {
    var dumped_text = "";
    if(!level) level = 0;
    
    //The padding given at the beginning of the line.
    var level_padding = "";
    for(var j=0;j<level+1;j++) level_padding += "    ";
    
    if(typeof(arr) == 'object') { //Array/Hashes/Objects
     for(var item in arr) {
      var value = arr[item];
     
      if(typeof(value) == 'object') { //If it is an array,
       dumped_text += level_padding + "'" + item + "' ...\n";
       dumped_text += dump(value,level+1);
      } else {
       dumped_text += level_padding + "'" + item + "'=>\"" + value + "\"\n";
      }
     }
    } else { //Stings/Chars/Numbers etc.
     dumped_text = "===>"+arr+"<===("+typeof(arr)+")";
    }
    return dumped_text;
} 

function show_tab(tab_name,div) {
    $("#" + div + " ul.tabs li").removeClass("active");
    $("#" + div + " .sim_tab").hide();
    $("#" + div + " .tab-nav[data-tabnav='" + tab_name + "']").addClass("active").show();
    $("#" + div + " .sim_tab[data-tab='" + tab_name + "']").fadeIn();
    return false;
}

function format(value,key) {
    if (!IsNumeric(value)) {
        return value;
    }
    if (value > 1000 || value < -1000 ) {
        value = Math.round(value);
    } else {
        value = Math.round(value*100)/100;
    }
    var isNegative = value < 0;
    var formattedString = addCommas(value);
    if (isNegative) {

        formattedString = "(" + formattedString.substring(1,formattedString.length) + ")";
    }
    return formattedString;
}

function addCommas(nstr) {
    nstr += '';
    var x = nstr.split('.');
    var x1 = x[0];
    var x2 = x.length > 1 ? '.' + x[1] : '';
    var rgx = /(\d+)(\d{3})/;
    while (rgx.test(x1)) {
        x1 = x1.replace(rgx, '$1' + ',' + '$2');
    }
    return x1 + x2;
}
function IsNumeric(n)
{
    return !isNaN(parseFloat(n)) && isFinite(n);
}

function computeProforma(onSuccess) {
  var url = document.location.pathname;
  var data = $('form.edit_decision').serialize();
  
  //$('form.edit_decision input[type=submit]').attr('disabled', 'disabled');
  
  successCB = function() {
    $('#async-status').hide();
    onSuccess();
  }

  $('#async-status').show();
  $.post(url, data, successCB, 'script');
}

function calculate(overdraft) {
  
  // Copy decision input values to hidden input fields in form
  $("[data-decision]").each(function(i,element){
     var decision = $(element).attr("data-decision");
     var val = parseFloat($(element).contents().val());
     decisions[decision] = val;
     $('#decision_'+decision_map[decision]).val(val);
  });

  // store tab state
  var activeTab = $('#financials li.tab-nav.active').attr('data-tabnav');
  if (typeof activeTab === 'undefined' || activeTab === null) {
    activeTab = 'balance sheet';
  }
  // 
  return computeProforma(function() {
    //$('form.edit_decision input[type=submit]').removeAttr('disabled');
    
    // restore tab state
    $('#financials li.tab-nav[data-tabnav="' + activeTab + '"]').addClass('active');
    $('div[data-tab="' + activeTab + '"]').show();

    //This stuff seems to calculate some sums in the decision pane so
    //was not removed -chris
    $("[data-formula]").each(function(i, e) {
      var formula = $(e).attr("data-formula");
      var tokens = formula.match(/{.*?}/g);
      $.each(tokens, function(i, token) {
        var cell = token.replace(/[{}]/g, "");
        var value = $("[data-decision='" + cell + "'] input").val();
        if (value == null) {
          value = previous[cell];
        }
        if (value == null || value == "") {
          value = "0";
        }

        formula = formula.replace(token, value);

      });
      $(e).html(format(eval(formula), ""));
      
    });
    
    $("[data-formula-previous]").each(function(i, e) {
      var formula = $(e).attr("data-formula-previous");
      var tokens = formula.match(/{.*?}/g);
      $.each(tokens, function(i, token) {
        var cell = token.replace(/[{}]/g, "");
        var value = previous[cell];

        if (value == null || value == "") {
          value = "0";
        }

        formula = formula.replace(token, value);

      });
      $(e).html(format(eval(formula), ""));
      
    });
    
    initLabels();
    initCurrencies();
    initUnitLabels();
  });

}



$(document).ready(function() {
    initDecision();
    //debug
    //document.getElementById("datadump").innerHTML = dump(proforma);
    $("#decisions ul.tabs li:first").addClass("active").show();
    $("#financials ul.tabs li:first").addClass("active").show();
    $("#decisions .sim_tab:first").show();
    $("#financials .sim_tab:first").show();
    $('td[data-previous]').css("text-align","right");
    $('td[data-proforma]').css("text-align","right");
    $('td[data-formula]').css("text-align","right");
    $('td[data-formula-previous]').css("text-align","right");
    //added by chris for data moved over to @proforma hash
    $('td[pfvalues]').css("text-align","right");
});
     