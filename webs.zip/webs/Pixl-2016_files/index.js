var initCurrencies, initDecision, initLabels, initUnitLabels;
initLabels = function() {
  return $("[data-label]").each(function(i, element) {
    var label;
    label = $(element).attr("data-label");
    return $(element).html(labels[label]);
  });
};
initCurrencies = function() {
  return $("[data-currency]").each(function(i, element) {
    var currency;
    currency = $(element).attr("data-currency");
    return $(element).html(currencies[currency]);
  });
};
initUnitLabels = function() {
  return $("[data-unit-label]").each(function(i, element) {
    var unit_label;
    unit_label = $(element).attr("data-unit-label");
    return $(element).html(unit_labels[unit_label]);
  });
};
initDecision = function() {
  var dashed, underscored;
  for (dashed in decision_map) {
    underscored = decision_map[dashed];
    if (underscored in locked_fields) {
      decisions[dashed] = locked_fields[underscored];
    }
  }
  initLabels();
  initCurrencies();
  initUnitLabels();
  $("[data-decision]").each(function(i, element) {
    var column, decision, initial_value, row, _ref;
    decision = $(element).attr("data-decision");
    initial_value = decisions[decision];
    $(element).html("<input size='4' value='" + initial_value + "' name='" + decision + "'>");
    if (decision_map[decision] in locked_fields) {
      if ($(element).attr('data-columnar') != null) {
        $(element).css('visibility', 'hidden');
        _ref = decision.split('-'), row = _ref[0], column = _ref[1];
        return $(element).closest('table').find("th[data-label=\"" + column + "\"]").css('visibility', 'hidden');
      } else {
        return $(element).parent('tr').css('display', 'none');
      }
    }
  });
  if (!canSellInternational) {
    $('input[name="ppu-p1-r3"]').attr('disabled', 'disabled');
    $('input[name="ppu-p2-r3"]').attr('disabled', 'disabled');
    $('input[name="ppu-p3-r3"]').attr('disabled', 'disabled');
    $('input[name="sales-p1-r3"]').attr('disabled', 'disabled');
    $('input[name="sales-p2-r3"]').attr('disabled', 'disabled');
    $('input[name="sales-p3-r3"]').attr('disabled', 'disabled');
    $('input[name="adv-p1-r3"]').attr('disabled', 'disabled');
    $('input[name="adv-p2-r3"]').attr('disabled', 'disabled');
    $('input[name="adv-p3-r3"]').attr('disabled', 'disabled');
    $('input[name="reps-r3"]').attr('disabled', 'disabled');
    $('#exchange-rate').html('');
  }
  if (!canSellProdZ) {
    $('input[name="ppu-p3-r1"]').attr('disabled', 'disabled');
    $('input[name="ppu-p3-r2"]').attr('disabled', 'disabled');
    $('input[name="ppu-p3-r3"]').attr('disabled', 'disabled');
    $('input[name="sales-p3-r1"]').attr('disabled', 'disabled');
    $('input[name="sales-p3-r2"]').attr('disabled', 'disabled');
    $('input[name="sales-p3-r3"]').attr('disabled', 'disabled');
    $('input[name="adv-p3-r1"]').attr('disabled', 'disabled');
    $('input[name="adv-p3-r2"]').attr('disabled', 'disabled');
    $('input[name="adv-p3-r3"]').attr('disabled', 'disabled');
    $('input[name="pa-p3"]').attr('disabled', 'disabled');
  }
  if (!canPayDividends) {
    $('input[name="dividends"]').attr('disabled', 'disabled');
  }
  if (!canAccessBankNotes) {
    $('input[name="st-debt"]').attr('disabled', 'disabled');
  }
	if (!canAccessLTDebt) {
    $('input[name="lt-debt-issue"]').attr('disabled', 'disabled');
  }
  $('[data-decision]').change(calculate);
  return $("[data-previous]").each(function(i, element) {
    var decision, initial_value;
    decision = $(element).attr("data-previous");
    initial_value = previous[decision];
    return $(element).html(format(initial_value, decision));
  });
};